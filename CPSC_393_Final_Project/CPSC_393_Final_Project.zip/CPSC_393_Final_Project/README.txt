David Aarhus (2291228) and Andy Anguiano (2316199)
Machine Learning IN21I CPSC-393-01
Dr. Linstead
1/27/2021
Final Project

References:

https://stackoverflow.com/questions/37372603/how-to-remove-specific-substrings-from-a-set-of-strings-in-python
https://stackoverflow.com/questions/26392336/importing-images-from-a-directory-python-to-list-or-dictionary
http://faculty.neu.edu.cn/yury/AAI/Textbook/Deep%20Learning%20with%20Python.pdf
https://stackoverflow.com/questions/3397752/copy-multiple-files-in-python/3399299
https://machinelearningmastery.com/how-to-perform-face-recognition-with-vggface2-convolutional-neural-network-in-keras/
https://stackoverflow.com/questions/44054082/keras-utils-to-categorical-name-keras-not-defined
